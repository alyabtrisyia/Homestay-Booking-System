package com.csc3402.security.homestay2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homestay2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
