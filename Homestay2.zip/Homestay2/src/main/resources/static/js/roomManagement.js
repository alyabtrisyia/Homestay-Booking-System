document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('availabilityForm');

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const roomType = document.getElementById('roomType').value;
        const url = `/availability.html?roomType=${roomType}`;
        window.location.href = url;
    });

    function getAllRooms() {
        fetch('/rooms')
            .then(response => response.json())
            .then(data => {
                const roomListDiv = document.getElementById('roomList');
                roomListDiv.innerHTML = '<h3>All Rooms:</h3>';
                data.forEach(room => {
                    roomListDiv.innerHTML += `<p>Room ID: ${room.roomId}, Room No: ${room.roomNo}, Room Type: ${room.roomType}, Room Price: ${room.roomPrice}</p>`;
                });
            })
            .catch(error => console.error('Error fetching rooms:', error));
    }

    getAllRooms(); // Fetch all rooms initially when the page loads
});
