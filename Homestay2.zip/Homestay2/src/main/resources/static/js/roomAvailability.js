document.addEventListener('DOMContentLoaded', function() {
    const availabilityForm = document.getElementById('availabilityForm');
    const availabilityResult = document.getElementById('availabilityResult');

    availabilityForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const roomType = document.getElementById('roomType').value;
        const checkinDate = document.getElementById('checkinDate').value;
        const checkoutDate = document.getElementById('checkoutDate').value;

        fetch(`/api/rooms/available?roomType=${roomType}&checkinDate=${checkinDate}&checkoutDate=${checkoutDate}`)
            .then(response => response.json())
            .then(data => {
                let html = '<h3>Available Rooms:</h3>';
                data.forEach(room => {
                    html += `<p>Room No: ${room.roomNo}, Room Type: ${room.roomType}, Room Price: ${room.roomPrice}</p>`;
                });
                availabilityResult.innerHTML = html;
            })
            .catch(error => {
                availabilityResult.innerHTML = `<div class="alert alert-danger">Error checking availability: ${error}</div>`;
            });
    });
});
