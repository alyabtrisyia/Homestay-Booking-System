package com.csc3402.security.homestay2.controller;

import com.csc3402.security.homestay2.dto.UserDto;
import com.csc3402.security.homestay2.model.BookedRoom;
import com.csc3402.security.homestay2.model.User;
import com.csc3402.security.homestay2.repository.BookedRoomRepository;
import com.csc3402.security.homestay2.repository.UserRepository;
import com.csc3402.security.homestay2.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @RequestMapping("/login")
    public String loginForm(){
        return "login";
    }

    @PostMapping("/login")
    public String loginPage(@RequestParam("email") String email,
                            @RequestParam("password") String password) {
        User user = userRepository.findByEmail(email);

        if (email.equals("admin_vvs@gmail.com") && password.equals("adminvvs")){
            return "redirect:/admin";
        }

        if (user != null && user.getPassword().equals(password)) {
            return "redirect:/rooms";
        } else {
            return "redirect:/login?error=true";
        }
    }

    @GetMapping("/registration")
    public String registrationForm(Model model){
        UserDto userDto = new UserDto();
        model.addAttribute("userDto", userDto);
        return "registration";
    }

    @PostMapping("/registration")
    public String registration(@Valid @ModelAttribute("userDto") UserDto userDto, BindingResult bindingResult, Model model){
        User existingUser = userService.findUserByEmail(userDto.getEmail());

        if (existingUser != null)
            bindingResult.rejectValue("email", null, "User already registered!!!");

        if (bindingResult.hasErrors()){
            model.addAttribute("userDto", userDto);
            return "/registration";
        }

        userService.saveUser(userDto);
        return "redirect:/registration?success";
    }

    @GetMapping("/logout")
    public String userLogout(){
        return "redirect:/login?logout";
    }
}
