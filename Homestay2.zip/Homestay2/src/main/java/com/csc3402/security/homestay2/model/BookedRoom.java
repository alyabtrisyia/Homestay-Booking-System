package com.csc3402.security.homestay2.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Entity
@Getter
@Setter
@AllArgsConstructor
@Table(name = "bookedRoom")
public class BookedRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bookedroom_id")
    private Long id;

    @Column(nullable = false)
    private LocalDate checkinDate;

    @Column(nullable = false)
    private LocalDate checkoutDate;

    @Column(nullable = false)
    private int adultQty;

    @Column(nullable = false)
    private int childrenQty;

    @Column(nullable = false)
    private String roomType;

    //@ManyToMany(mappedBy = "rooms")
    //private List<User> users = new ArrayList<>();

    public BookedRoom() {
    }

    @Override
    public String toString() {
        return "BookedRoom{" +
                "id=" + id +
                ", checkinDate=" + checkinDate +
                ", checkoutDate=" + checkoutDate +
                ", adultQty=" + adultQty +
                ", childrenQty=" + childrenQty +'}';
    }
}
