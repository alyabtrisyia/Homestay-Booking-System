package com.csc3402.security.homestay2.controller;

import com.csc3402.security.homestay2.model.BookedRoom;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/about")
    public String aboutMainMenu(){
        return "about";
    }

    @GetMapping("/services")
    public String serviceMainMenu() {
        return "services";
    }

    @GetMapping("/rooms")
    public String roomsMainMenu() {
        return "rooms";
    }

    @GetMapping("/contact")
    public String contactMainMenu() {
        return "contact";
    }

    @GetMapping("/teamMembers")
    public String teamMembers() {
        return "team";
    }

    @GetMapping("/deluxesuite")
    public String deluxeSuite(){
        return "deluxesuite";
    }

    @GetMapping("/familysuite")
    public String familySuite(){
        return "familysuite";
    }

    @GetMapping("/luxurypenthouse")
    public String luxuryPenthouse(){
        return "luxurypenthouse";
    }

    @GetMapping("/admin")
    public String adminHome() {
        return "index-admin";
    }

    @GetMapping("/list-room")
    public String listRoom(){
        return "list-room";
    }

    @GetMapping("/deleteroom")
    public String deleteRoom(){
        return "choose-room-to-delete";
    }
}
