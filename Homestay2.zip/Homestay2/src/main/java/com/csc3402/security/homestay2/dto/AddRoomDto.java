package com.csc3402.security.homestay2.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
public class AddRoomDto {
    private Long id;

    @NotEmpty(message = "Please enter valid date.")
    private LocalDate checkinDate;

    @NotEmpty(message = "Please enter valid date.")
    private LocalDate checkoutDate;

    private int adultQty;

    private int childrenQty;

    @NotEmpty(message = "Please enter valid unit type.")
    private String roomType;

    public AddRoomDto(){
    }
}
