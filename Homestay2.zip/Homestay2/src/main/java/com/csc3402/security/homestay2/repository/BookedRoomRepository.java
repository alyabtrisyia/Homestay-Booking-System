package com.csc3402.security.homestay2.repository;

import com.csc3402.security.homestay2.model.BookedRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BookedRoomRepository extends JpaRepository<BookedRoom, Long> {

   @Query(value = "SELECT * FROM bookedRoom WHERE bookedroom_id = :id", nativeQuery = true)
   BookedRoom findBookedRoomById(@Param("id") Long id);
}
