package com.csc3402.security.homestay2.service;

import com.csc3402.security.homestay2.dto.AddRoomDto;
import com.csc3402.security.homestay2.model.Admin;
import com.csc3402.security.homestay2.model.BookedRoom;

import java.util.List;
import java.util.Optional;

public interface BookedRoomService {

    List<BookedRoom> listAllBookedRooms();

    BookedRoom addNewRoom(BookedRoom bookedRoom);

    void saveRoom(AddRoomDto addRoomDto);

    Optional<BookedRoom> findBookedRoomById(Long bookedRoomId);

    BookedRoom updateBookedRoom(BookedRoom bookedRoom);

    void deleteBookedRoom(BookedRoom bookedRoom);
}
