package com.csc3402.security.homestay2.service;

import com.csc3402.security.homestay2.dto.AddRoomDto;
import com.csc3402.security.homestay2.dto.UserDto;
import com.csc3402.security.homestay2.model.BookedRoom;
import com.csc3402.security.homestay2.model.Role;
import com.csc3402.security.homestay2.model.User;
import com.csc3402.security.homestay2.repository.BookedRoomRepository;
import com.csc3402.security.homestay2.repository.RoleRepository;
import com.csc3402.security.homestay2.repository.UserRepository;
import com.csc3402.security.homestay2.util.TbConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BookedRoomRepository bookedRoomRepository;
    @Override
    public void saveUser(UserDto userDto){
        Role role = roleRepository.findByName(TbConstants.Roles.USER);

        if (role == null)
            role = roleRepository.save(new Role(TbConstants.Roles.USER));

        User user = new User(userDto.getId(), userDto.getName(), userDto.getEmail(), userDto.getPassword(), userDto.getPhone(), Arrays.asList(role));
        userRepository.save(user);
    }

    @Override
    public User findUserByEmail(String email){
        return userRepository.findByEmail(email);
    }
}
