package com.csc3402.security.homestay2.util;

public class TbConstants {
    public static interface Roles {
        String USER = "ROLE_USER";
        String ADMIN = "ROLE_ADMIN";
    }
}
