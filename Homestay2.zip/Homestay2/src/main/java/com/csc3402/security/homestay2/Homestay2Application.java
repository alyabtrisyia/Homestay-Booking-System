package com.csc3402.security.homestay2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Homestay2Application {

    public static void main(String[] args) {
        SpringApplication.run(Homestay2Application.class, args);
    }

}
