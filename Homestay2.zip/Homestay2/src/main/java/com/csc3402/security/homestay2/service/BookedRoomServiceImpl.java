package com.csc3402.security.homestay2.service;

import com.csc3402.security.homestay2.dto.AddRoomDto;
import com.csc3402.security.homestay2.model.BookedRoom;
import com.csc3402.security.homestay2.repository.BookedRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BookedRoomServiceImpl implements BookedRoomService {

    @Autowired
    private BookedRoomRepository bookedRoomRepository;

    public BookedRoomServiceImpl(BookedRoomRepository bookedRoomRepository){
        this.bookedRoomRepository = bookedRoomRepository;
    }

    @Override
    public List<BookedRoom> listAllBookedRooms() {
        return bookedRoomRepository.findAll();
    }

    @Override
    public BookedRoom addNewRoom(BookedRoom bookedRoom) {
        return bookedRoomRepository.save(bookedRoom);
    }

    @Override
    public void saveRoom(AddRoomDto addRoomDto){
        BookedRoom bookedRoom = new BookedRoom(addRoomDto.getId(), addRoomDto.getCheckinDate(), addRoomDto.getCheckoutDate(), addRoomDto.getAdultQty(), addRoomDto.getChildrenQty(), addRoomDto.getRoomType());
        bookedRoomRepository.save(bookedRoom);
    }

    @Override
    public Optional<BookedRoom> findBookedRoomById(Long bookedRoomId) {
        return bookedRoomRepository.findById(bookedRoomId);
    }

    @Override
    public BookedRoom updateBookedRoom(BookedRoom bookedRoom) {
        return bookedRoomRepository.save(bookedRoom);
    }

    @Override
    public void deleteBookedRoom(BookedRoom bookedRoom){
        bookedRoomRepository.delete(bookedRoom);
    }
}
