package com.csc3402.security.homestay2.service;

public interface UserDetailsService {
}
