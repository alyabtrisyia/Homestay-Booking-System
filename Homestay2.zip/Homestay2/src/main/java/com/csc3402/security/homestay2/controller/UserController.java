package com.csc3402.security.homestay2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user/")
public class UserController {

    //User redirect to rooms.html after successfully login
    @PostMapping("/rooms")
    public String roomsPage() {
        return "rooms";
    }
}
