package com.csc3402.security.homestay2.controller;

import com.csc3402.security.homestay2.dto.AddRoomDto;
import com.csc3402.security.homestay2.model.BookedRoom;
import com.csc3402.security.homestay2.repository.BookedRoomRepository;
import com.csc3402.security.homestay2.service.BookedRoomService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
public class BookedRoomController {

    @Autowired
    private BookedRoomRepository bookedRoomRepository;

    private final BookedRoomService bookedRoomService;

    public BookedRoomController(BookedRoomService bookedRoomService){
        this.bookedRoomService = bookedRoomService;
    }

    @PostMapping("/book/deluxe")
    public String bookDeluxe(@RequestParam("checkin") String checkin,
                             @RequestParam("checkout") String checkout,
                             @RequestParam("adults") int adults,
                             @RequestParam("children") int children) {
        BookedRoom booking = new BookedRoom();
        booking.setCheckinDate(LocalDate.parse(checkin));
        booking.setCheckoutDate(LocalDate.parse(checkout));
        booking.setAdultQty(adults);
        booking.setChildrenQty(children);
        booking.setRoomType("Deluxe Suite");
        bookedRoomRepository.save(booking);
        return "success";
    }

    @PostMapping("/book/family")
    public String bookFamily(@RequestParam("checkin") String checkin,
                             @RequestParam("checkout") String checkout,
                             @RequestParam("adults") int adults,
                             @RequestParam("children") int children) {
        BookedRoom booking = new BookedRoom();
        booking.setCheckinDate(LocalDate.parse(checkin));
        booking.setCheckoutDate(LocalDate.parse(checkout));
        booking.setAdultQty(adults);
        booking.setChildrenQty(children);
        booking.setRoomType("Family Suite");
        bookedRoomRepository.save(booking);
        return "success";
    }

    @PostMapping("/book/luxury")
    public String bookLuxury(@RequestParam("checkin") String checkin,
                             @RequestParam("checkout") String checkout,
                             @RequestParam("adults") int adults,
                             @RequestParam("children") int children) {
        BookedRoom booking = new BookedRoom();
        booking.setCheckinDate(LocalDate.parse(checkin));
        booking.setCheckoutDate(LocalDate.parse(checkout));
        booking.setAdultQty(adults);
        booking.setChildrenQty(children);
        booking.setRoomType("Luxury Penthouse");
        bookedRoomRepository.save(booking);
        return "success";
    }

    @GetMapping("list")
    public String showAllBookedRoom(Model model){
        model.addAttribute("rooms", bookedRoomService.listAllBookedRooms());
        return "list-room";
    }

    @GetMapping("signup")
    public String showAddNewRoom(BookedRoom bookedRoom){
        return "add-room";
    }

    @PostMapping("add")
    public String addRoom(@Valid BookedRoom bookedRoom, BindingResult bindingResult, Model model){
        if (bindingResult.hasErrors()){
            return "add-room";
        }

        bookedRoomService.addNewRoom(bookedRoom);
        return "redirect:list";
    }

    @GetMapping("update")
    public String showUpdateMain(Model model){
        model.addAttribute("rooms", bookedRoomService.listAllBookedRooms());
        return "choose-room-to-update";
    }

    @GetMapping("edit/{id}")
    public String showUpdate(@PathVariable("id") long id, Model model){
        BookedRoom bookedRoom = bookedRoomService.findBookedRoomById((Long) id)
                .orElseThrow(()-> new IllegalArgumentException("Invalid unit Id:" + id));

        model.addAttribute("bookedRoom", bookedRoom);
        return "update-room";
    }

    @PostMapping("update/{id}")
    public String updateRoom(@PathVariable("id") Long id, @Valid BookedRoom bookedRoom, BindingResult bindingResult, Model model){
        if (bindingResult.hasErrors()){
            bookedRoom.setId(id);
            return "index-admin";
        }

        model.addAttribute("rooms", bookedRoomService.listAllBookedRooms());
        bookedRoomService.updateBookedRoom(bookedRoom);
        return "list-room";
    }

    @GetMapping("delete")
    public String showDeleteMain(Model model){
        model.addAttribute("rooms", bookedRoomService.listAllBookedRooms());
        return "choose-room-to-delete";
    }

    @GetMapping("delete/{id}")
    public String deleteRoom(@PathVariable("id") long id, Model model){
        BookedRoom bookedRoom = bookedRoomService.findBookedRoomById((Long) id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid unit Id:" + id));

        bookedRoomService.deleteBookedRoom(bookedRoom);
        model.addAttribute("rooms", bookedRoomService.listAllBookedRooms());

        return "list-room";
    }

}
